import UserArray from './user_array.js'

const arr = new UserArray([{
  id: 0,
  description: 'desc0',
  createdAt: 'createdat0',
  author: 'author0',
  name: 'Olesya',
  surname: 'Losik',
  phoneNumber: '+353454454',
  email: 'losik2004@gmail.com',
  login: 'olesya',
  password: 'losik',
  contacts: [1, 2, 3]
}])

console.log('getUsers')
console.log(arr.getUsers(0, 1, { author: 'author0' }))
console.log('getUser')
console.log(arr.getUser(0))
console.log('validateUserTrue')
console.log(arr.validateUser({
  id: 0,
  description: 'desc0',
  createdAt: 'createdat0',
  author: 'author0',
  name: 'Olesya',
  surname: 'Losik',
  phoneNumber: '+353454454',
  email: 'losik2004@gmail.com',
  login: 'olesya',
  password: 'losik',
  contacts: [1, 2, 3]
}))
console.log('validateUserFalse')
console.log(arr.validateUser({
  id: 0,
  description: 'desc0',
  createdAt: 'createdat0',
  author: 'author0',
  name: 'Olesya',
  surname: 'Losik',
  phoneNumber: '+353454454',
  email: 'losik2004@gmail.com',
  login: 'olesya',
  contacts: [1, 2, 3]
}))

console.log('addUserTrue')
arr.addUser({
  id: 0,
  description: 'desc0',
  createdAt: 'createdat0',
  author: 'author0',
  name: 'Olesya',
  surname: 'Losik',
  phoneNumber: '+353454454',
  email: 'losik2004@gmail.com',
  login: 'olesya',
  password: 'losik',
  contacts: [1, 2, 3]
})
console.log(arr.getUsers())
console.log('addUserFalse')
arr.addUser({
  id: 0,
  description: 'desc0',
  createdAt: 'createdat0',
  author: 'author0',
  name: 'Olesya',
  surname: 'Losik',
  phoneNumber: '+353454454',
  email: 'losik2004@gmail.com',
  login: 'olesya',
  contacts: [1, 2, 3]
})
console.log(arr.getUsers())
console.log('clear')
arr.clear()
arr.getUsers()
console.log('addAll')
arr.addAll([{
  id: 0,
  description: 'desc0',
  createdAt: 'createdat0',
  author: 'author0',
  name: 'Olesya',
  surname: 'Losik',
  phoneNumber: '+353454454',
  email: 'losik2004@gmail.com',
  login: 'olesya',
  password: 'losik',
  contacts: [1, 2]
},
{
  id: 1,
  description: 'desc1',
  createdAt: 'createdat1',
  author: 'author1',
  name: 'Olesya1',
  surname: 'Losik',
  phoneNumber: '+353454454',
  email: 'losik12004@gmail.com',
  login: 'olesya1',
  password: 'losik1',
  contacts: [0, 2]
},
{
  id: 2,
  description: 'desc2',
  createdAt: 'createdat2',
  author: 'author2',
  name: 'Olesya2',
  surname: 'Losik',
  phoneNumber: '+353454454',
  email: 'losik22004@gmail.com',
  login: 'olesya2',
  password: 'losik2',
  contacts: [0, 1]
}])
console.log(arr.getUsers())
console.log('removeUser')
arr.removeUser(0)
console.log(arr.getUsers())
console.log('editUser')
arr.editUser(1, { description: 'newdesc', login: 'newlogin' })
console.log(arr.getUsers())
