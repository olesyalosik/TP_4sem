/* eslint-disable no-unused-vars */
class MessageArray {
  _arr = []

  _compareById (a, b) {
    return a.id < b.id
  }

  getMessages (skip = 0, top = 10, filterConfig) {
    let res = []
    res = this._arr.filter((e) => (this._arr.indexOf(e) < skip + top && this._arr.indexOf(e) >= skip))
    if (filterConfig !== undefined) {
      res = res.filter((e) => {
        return e[Object.keys(filterConfig)[0]] === filterConfig[Object.keys(filterConfig)[0]]
      })
    }
    return res.sort(this._compareById)
  }

  getMessage (id) {
    let res
    this._arr.forEach((e) => {
      if (e.id === id) res = e
    })
    return res
  }

  validateMessage (message) {
    if (message.id == null || message.description == null || message.createdAt == null || message.author == null || message.text == null) {
      return false
    }
    return true
  }

  addMessage (message) {
    if (!this.validateMessage(message)) {
      return false
    }
    this._arr.push(message)
    return true
  }

  editMessage (id, message) {
    let index = -1
    this._arr.forEach((e) => {
      if (e.id === id) {
        index = this._arr.indexOf(e)
      }
    })
    if (index === -1) {
      return
    }
    for (const property in message) {
      this._arr.at(index)[property] = message[property]
    }
  }

  removeMessage (id) {
    let indexToRemove = -1
    this._arr.forEach((e) => {
      if (e.id === id) {
        indexToRemove = this._arr.indexOf(e)
      }
    })
    if (indexToRemove > -1) {
      this._arr.splice(indexToRemove, 1)
    }
  }

  addAll (messages) {
    messages.forEach((e) => {
      if (this.validateUser(e)) {
        this._arr.push(e)
      }
    })
  }

  clear () {
    this._arr = []
  }

  length () {
    return this._arr.length
  }
}

/* eslint-disable no-unused-vars */
class MessageView {
  arr = new MessageArray()

  render () {
    document.getElementById('messages').replaceChildren()
    this.arr._arr.forEach((element) => {
      const li = document.createElement('li')
      li.textContent = element.text
      li.className = 'message_element'
      document.getElementById('messages').appendChild(
        li
      )
    }
    )
  }

  sendMessage (messageText) {
    console.log(this.arr.addMessage({
      id: this.arr.length() > 0 ? this.arr._arr[this.arr.length() - 1].id + 1 : 0,
      description: 'message',
      createdAt: Date.now,
      author: 'user',
      text: messageText
    }))
    console.log(this.arr._arr)
    console.log(this.arr.length())
    this.render()
  }

  removeMessage (id) {
    this.arr.removeMessage(id)
    this.render()
  }
}

const view = new MessageView()

document.getElementById('sendMessage').addEventListener('click', function () {
  const messageText = document.getElementById('messageText').value
  view.sendMessage(messageText)
})
