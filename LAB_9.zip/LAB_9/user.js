/* eslint-disable no-unused-vars */
class User {
    #id;
    #description;
    #createdAt;
    #author;
    #name;
    #surname;
    #phoneNumber;
    #email;
    #login;
    #password;
    #contacts;
    constructor(id, description, createdAt, author, name, surname, phoneNumber, email, login, password, contacts){
        this.#id = id;
        this.#description = description;
        this.#createdAt = createdAt;
        this.#author = author;
        this.#name = name;
        this.#surname = surname;
        this.#phoneNumber = phoneNumber;
        this.email = email;
        this.#login = login;
        this.#password = password;
        this.#contacts = contacts;
    }
}